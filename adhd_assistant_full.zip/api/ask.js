const fs = require("fs");
const path = require("path");

// Node 18+ has global fetch

const crisisWords = ["bunuh diri", "mengakhiri hidup", "tidak ingin hidup", "suicide"];

function crisisText() {
  return `Aku menyesal kamu sedang merasa sangat berat. Jika kamu berada dalam bahaya atau berpikir untuk menyakiti diri sendiri:
- Hubungi layanan darurat setempat sekarang
- Hubungi 119 ext 8 (Hotline Kesehatan Jiwa Indonesia) atau layanan terdekat
Kamu tidak sendirian — mencari bantuan adalah langkah berani.`;
}

function loadText(rel) {
  try {
    const p = path.join(process.cwd(), rel);
    return fs.readFileSync(p, "utf8");
  } catch { return ""; }
}

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { message, history = [] } = req.body || {};
  if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: "Missing OPENAI_API_KEY" });
  if (typeof message !== "string" || !message.trim()) return res.status(400).json({ error: "message required" });

  const lower = message.toLowerCase();
  if (crisisWords.some(w => lower.includes(w))) {
    return res.json({ answer: crisisText() });
  }

  const systemPrompt = loadText("prompts/system.txt");
  let fewshot = [];
  try { fewshot = JSON.parse(loadText("prompts/fewshot.json") || "[]"); } catch {}

  const messages = [
    { role: "system", content: systemPrompt },
    ...fewshot,
    ...history.slice(-6),
    { role: "user", content: message }
  ];

  try {
    const r = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages,
        temperature: 0.4
      })
    });

    if (!r.ok) {
      const text = await r.text();
      return res.status(500).json({ error: "OpenAI error", detail: text });
    }
    const data = await r.json();
    const answer = data.choices?.[0]?.message?.content ?? "Maaf, aku tidak menemukan jawaban.";
    return res.json({ answer });
  } catch (err) {
    return res.status(500).json({ error: "Server error", detail: String(err) });
  }
};
