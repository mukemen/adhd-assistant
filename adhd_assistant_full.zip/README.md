# ADHD Assistant (ID)

Asisten edukasi ADHD berbahasa Indonesia.  
Dibuat oleh **MUKEMEN.AI** untuk membantu orang memahami ADHD dengan cara sederhana, suportif, dan berbasis bukti.

## Cara jalanin (Vercel)
1) Import repo ini ke vercel.com
2) Tambah **Environment Variable**: `OPENAI_API_KEY` = `sk-...`
3) Deploy → buka URL → tanya apa saja seputar ADHD

## Fitur
- Jawaban ringkas, empatik, berbasis bukti
- Tips praktis (Pomodoro, chunking, pengingat)
- Rujukan: CDC, NICE, APA
- Guard krisis: mengarahkan ke 119 ext 8 bila perlu

## Disclaimer
Aplikasi ini hanya untuk **edukasi**. Bukan alat diagnosis/terapi. Konsultasikan keputusan kesehatan ke tenaga profesional.
