# Deskripsi Panjang

ADHD Assistant adalah asisten virtual edukasi berbahasa Indonesia.  
Dikembangkan untuk memberikan informasi terpercaya, tips praktis, dan dukungan sehari-hari kepada individu yang ingin memahami Attention Deficit Hyperactivity Disorder (ADHD).

### Bisa apa?
- Menjelaskan gejala umum ADHD pada anak & dewasa
- Memberi strategi harian: manajemen waktu, fokus, pengingat
- Menyertakan sumber tepercaya (CDC, NICE, APA)
- Pesan darurat bila ada indikasi krisis

### Tidak bisa apa?
- Diagnosis medis
- Saran obat/dosis spesifik
- Menggantikan dokter/psikolog/psikiater

> **Disclaimer:** Konten ini hanya untuk edukasi. Untuk kekhawatiran medis, hubungi tenaga kesehatan.
